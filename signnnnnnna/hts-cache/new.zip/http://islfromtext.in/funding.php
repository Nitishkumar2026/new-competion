<!DOCTYPE html>
<html>
    <head>
    	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="author" content="Divanshu Singh - Thapar University" >
<link rel="icon" href="images/favicon.png">
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
<!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
<!--[if lt IE 9]><script src="js/ie8-responsive-file-warning.js"></script><![endif]-->
<script src="js/ie-emulation-modes-warning.js"></script>
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
<link href="https://fonts.googleapis.com/css?family=Baloo" rel="stylesheet"> 
<link href="css/custom.css" rel="stylesheet">
<script type="text/javascript" src="js/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>          <title>ISL : Home Page</title>           
    </head>
    <body>
    <!-- Fixed navbar -->
<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar" style="background:#337ab7;color:white;">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
     <a class="navbar-brand" href="index.php" style="padding:0;padding-left:10px;"><h1 style="padding:0; margin:0;"><img src="admin/logo.png" style="height:55px;"></h1></a>
    </div>
    <div id="navbar" class="navbar-collapse collapse">
      <ul class="nav navbar-nav">
        
      </ul>
      <ul class="nav navbar-nav navbar-right">
<li ><a href="index.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
<li ><a href="avatarfinal.php">Try System Now</a></li>  
<li ><a href="https://chrome.google.com/webstore/detail/convert-text-to-isl/cnjkedbgijbppmonekeajnbdokgmkekd?utm_source=chrome-ntp-icon">Chrome-Extension</a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Project<span class="caret"></span></a>
          <ul class="dropdown-menu" role="menu">
            <li><a href="history.php">History</a></li>
            <li><a href="objective.php">Objective</a></li>
            <li><a href="working.php">Working</a></li>
            <li><a href="funding.php">Funding</a></li>
            <li><a href="contributors.php">Contributors</a></li>
            <li><a href="publications.php">Publications</a></li>
          </ul>
        </li>
        <!-- <li ><a href="#">Workshop</a></li> -->
	<li ><a href="team.php">Team</a></li>	
	<li ><a href="consultancy.php"><mark>Collaborate/Consultancy</mark></a></li>
        <li ><a href="contact.php">Contact</span></a></li>
      </ul>
    </div><!--/.nav-collapse -->
  </div>
</nav>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
<!-- Put your code after this -->
		<h3 class="text-center">Project Title</h3>
		<p class="text-center">Automatic Generation of Sign Language from Hindi Text for communication and education of hearing impaired people. </p>
		<h3 class="text-center">Funding Agency</h3>
		<p class="text-center">SEED Division of DST</p>
		<h3 class="text-center">Funding Amount</h3>
		<p class="text-center">Rs.17,26,560</p>
<!-- Put your code before this -->
            </div>
        </div>
    </div>
<div class="container">
    <div class="row">
        <div class="col-md-12 text-center" style="font-size:13px; margin-bottom:20px;"><hr>
"Truth Triumphs; Falsehood Never" - Thapar University
        </div>
    </div>
</div>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-113307373-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-113307373-1');
</script>
<script>

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

</script>	</body>
</html>	
