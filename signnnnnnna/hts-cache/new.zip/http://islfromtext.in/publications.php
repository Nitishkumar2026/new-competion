<!DOCTYPE html>
<html>
    <head>
    	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="author" content="Divanshu Singh - Thapar University" >
<link rel="icon" href="images/favicon.png">
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
<!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
<!--[if lt IE 9]><script src="js/ie8-responsive-file-warning.js"></script><![endif]-->
<script src="js/ie-emulation-modes-warning.js"></script>
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
<link href="https://fonts.googleapis.com/css?family=Baloo" rel="stylesheet"> 
<link href="css/custom.css" rel="stylesheet">
<script type="text/javascript" src="js/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>          <title>ISL : Home Page</title>           
    </head>
    <body>
    <!-- Fixed navbar -->
<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar" style="background:#337ab7;color:white;">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
     <a class="navbar-brand" href="index.php" style="padding:0;padding-left:10px;"><h1 style="padding:0; margin:0;"><img src="admin/logo.png" style="height:55px;"></h1></a>
    </div>
    <div id="navbar" class="navbar-collapse collapse">
      <ul class="nav navbar-nav">
        
      </ul>
      <ul class="nav navbar-nav navbar-right">
<li ><a href="index.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
<li ><a href="avatarfinal.php">Try System Now</a></li>  
<li ><a href="https://chrome.google.com/webstore/detail/convert-text-to-isl/cnjkedbgijbppmonekeajnbdokgmkekd?utm_source=chrome-ntp-icon">Chrome-Extension</a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Project<span class="caret"></span></a>
          <ul class="dropdown-menu" role="menu">
            <li><a href="history.php">History</a></li>
            <li><a href="objective.php">Objective</a></li>
            <li><a href="working.php">Working</a></li>
            <li><a href="funding.php">Funding</a></li>
            <li><a href="contributors.php">Contributors</a></li>
            <li><a href="publications.php">Publications</a></li>
          </ul>
        </li>
        <!-- <li ><a href="#">Workshop</a></li> -->
	<li ><a href="team.php">Team</a></li>	
	<li ><a href="consultancy.php"><mark>Collaborate/Consultancy</mark></a></li>
        <li ><a href="contact.php">Contact</span></a></li>
      </ul>
    </div><!--/.nav-collapse -->
  </div>
</nav>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
<!-- Put your code after this -->
		<h2>Publications</h2>
		<ol>
			<li><a href="http://ieeexplore.ieee.org/document/6968333/?denied">Rupinder Kaur, and Parteek Kumar. "HamNoSys generation system for sign language." Advances in Computing, Communications and Informatics (ICACCI, 2014 International Conference on. IEEE, 2014.</a></li>
			<li><a href="http://www.sciencedirect.com/science/article/pii/S1877050916311280">Khushdeep Kaur, Parteek Kumar, HamNoSys to SiGML Conversion System for Sign Language Automation, Procedia Computer Science, Volume 89, 2016, Pages 794-803, ISSN 1877-0509, http://dx.doi.org/10.1016/j.procs.2016.06.063.</a> (http://www.sciencedirect.com/science/article/pii/S1877050916311280) Keywords: HamNoSys; ISL; JASigning URL App; SiGML</li>
			<li><a href="http://dspace.thapar.edu:8080/jspui/handle/10266/2859">Rupinder Kaur and Parteek Bhatia,Sign Language Automation. Diss. THAPAR UNIVERSITY PATIALA, 2014.</a></li>
			<li><a href="http://www.islfromtext.in/publications.jsp">Khushdeep Kaur and Parteek Bhatia,HamNoSys based Indian Sign Language Generation System</a></li>
			<li><a href="http://dspace.thapar.edu:8080/jspui/handle/10266/4284">Paras Vij and Parteek Bhatia,Translator of Hindi Text to ISL and extension of ISL dictionary with WordNet</a></li>
			<li><a href="http://waset.org/publications/10009433/pdf">Sugandhi, Kumar, P. , Kaur, S. (2018). 'Online Multilingual Dictionary Using Hamburg Notation for Avatar-Based Indian Sign Language Generation System '. World Academy of Science, Engineering and Technology, International Science Index 140, International Journal of Social, Behavioral, Educational, Economic, Business and Industrial Engineering, 12(8), 1116 - 1123. </a></li>
		</ol>
<!-- Put your code before this -->
            </div>
        </div>
    </div>
<div class="container">
    <div class="row">
        <div class="col-md-12 text-center" style="font-size:13px; margin-bottom:20px;"><hr>
"Truth Triumphs; Falsehood Never" - Thapar University
        </div>
    </div>
</div>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-113307373-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-113307373-1');
</script>
<script>

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

</script>	</body>
</html>	
